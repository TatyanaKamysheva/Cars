CREATE TRIGGER ID_MAN
  BEFORE INSERT
  ON MANAGER
  FOR EACH ROW
  begin
    if :new.ID_MANAGER is null then
      select MANAG.nextval into :new.ID_MANAGER from dual;
    end if;
  end;
/

